//
//  AppData.swift
//  Demo
//
//  Created by Shehab, Mohamed on 3/19/19.
//  Copyright © 2019 UNCC. All rights reserved.
//

import Foundation

class AppData {
    
    let cities = [
        "US":["Charlotte", "Chicago", "New York", "Miami", "San Francisco", "Baltimore", "Houston"],
        "UK":["London", "Bristol", "Cambridge", "Liverpool"],
        "AE":["Abu Dhabi", "Dubai", "Sharjah"],
        "JP":["Tokyo", "Kyoto", "Hashimoto", "Osaka"]
    ]
    
}
