//
//  ThreadsViewController.swift
//  MidtermExam
//
//  Created by Shehab, Mohamed on 11/22/19.
//  Copyright © 2019 UNCC. All rights reserved.
//

import UIKit
import Alamofire

class ThreadsViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        getThreads()
    }
    
    
    func getThreads() {
        let headers: HTTPHeaders = [
            "Authorization": "BEARER token-received-after-login-or-signup-here",
            "Accept": "application/json"
        ]
        
        let token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE1NzQ0MTAxMDEsImV4cCI6MTYwNjAzMjUwMSwianRpIjoiNDNacmtzOHB2WHZQUlNVSkdaMkJPWiIsInVzZXIiOjJ9.xUf3PB3uOH8y5S48T1IT0hx_1rr64rp9NOI790exiE4"
        
        let exampleHeaders : HTTPHeaders = [
            "Authorization": "BEARER \(token)",
            "Accept": "application/json"
        ]
        
        AF.request("http://ec2-18-234-222-229.compute-1.amazonaws.com/api/threads",
                   method: .get,
                   parameters: nil,
                   headers: exampleHeaders).responseJSON { (response) in
            print(response.value)
        }
    }

}
