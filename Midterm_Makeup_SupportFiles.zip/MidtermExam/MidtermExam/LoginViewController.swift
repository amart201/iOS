//
//  LoginViewController.swift
//  MidtermExam
//
//  Created by Shehab, Mohamed on 11/22/19.
//  Copyright © 2019 UNCC. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func signupClicked(_ sender: Any) {
        AppDelegate.showSignUp()
    }
    
    @IBAction func loginClicked(_ sender: Any) {
        AppDelegate.showThreadsList()
    }
}
