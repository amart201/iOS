//
//  ProfileViewController.swift
//  InClass03
//
//  Created by Martin, Aaron on 9/16/19.
//  Copyright © 2019 Martin, Aaron. All rights reserved.
//

import UIKit

class ProfileViewController: UIViewController {
    
    @IBOutlet weak var nameOutput: UILabel!
    @IBOutlet weak var emailOutput: UILabel!
    @IBOutlet weak var passwordOutput: UILabel!
    @IBOutlet weak var departmentOutput: UILabel!
    @IBOutlet weak var passwordShowButton: UIButton!
    
    var name:String?
    var email:String?
    var password:String?
    var department:String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if name != nil {
            self.nameOutput.text = name
        }
        if email != nil {
            self.emailOutput.text = email
        }
        if password != nil {
            var hiddenPassword:String = ""
            for i in 1...password!.count {
                hiddenPassword.append("*")
            }
            self.passwordOutput.text = hiddenPassword
        }
        if department != nil {
            self.departmentOutput.text = department
        }
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func passwordShow(_ sender: Any) {
        if self.passwordShowButton.currentTitle == "Show" {
            self.passwordOutput.text = password
            self.passwordShowButton.setTitle("Hide", for: .normal)
        } else if self.passwordShowButton.currentTitle == "Hide" {
            var hiddenPassword:String = ""
            for i in 1...password!.count {
                hiddenPassword.append("*")
            }
            self.passwordOutput.text = hiddenPassword
            self.passwordShowButton.setTitle("Show", for: .normal)
        }
    }
    
    
    @IBAction func closeProfileView(_ sender: Any) {
        self.dismiss(animated: true) {
            
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
