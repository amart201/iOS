//
//  ViewController.swift
//  Class03
//
//  Created by Blaser, Elliott on 9/16/19.
//  Copyright © 2019 Blaser, Elliott. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBOutlet weak var TextFieldName: UITextField!
    @IBOutlet weak var TextFieldEmail: UITextField!
    @IBOutlet weak var TextFieldPassword: UITextField!
    @IBOutlet weak var SegmentedDepartment: UISegmentedControl!
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let destinationVC = segue.destination as! ViewControllerName
        destinationVC.name = self.TextFieldName.text
        destinationVC.email = self.TextFieldEmail.text
        destinationVC.password = self.TextFieldPassword.text
        destinationVC.department = self.SegmentedDepartment.titleForSegment(at: self.SegmentedDepartment.selectedSegmentIndex)
    }
    
    private func sendError(String msg: String)
    {
        let alert = UIAlertController(title: "Error!", message: msg, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Wonderful!", style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        
        if (identifier == "SegueToName")
        {
            if (self.TextFieldName.text == "")
            {
                sendError(String: "You need to enter a name!")
                return false
            }
            else if (self.TextFieldEmail.text == "")
            {
                sendError(String: "You need to enter an email!")
                return false
            }
            else if (self.TextFieldPassword.text == "")
            {
                sendError(String: "You need to enter a password!")
                return false
            }
            else
            {
                return true
            }
        }
        return true
    }
}

