//
//  ViewControllerEditDepart.swift
//  Class03
//
//  Created by Blaser, Elliott on 9/16/19.
//  Copyright © 2019 Blaser, Elliott. All rights reserved.
//

import UIKit

class ViewControllerEditDepart: UIViewController {

    @IBOutlet weak var SegmentDepart: UISegmentedControl!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func CloseEditName(_ sender: Any) {
        self.dismiss(animated: true)
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vc = segue.destination as! ViewControllerName
        vc.department = self.SegmentDepart.titleForSegment(at: SegmentDepart.selectedSegmentIndex)
    }
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        if (self.SegmentDepart.selectedSegmentIndex == -1)
        {
            let alert = UIAlertController(title: "Error!", message: "You need to select a department!", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "For the King!", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            return false
        }
        else
        {
            return true
        }
    }
}
