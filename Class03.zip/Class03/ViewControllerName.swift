//
//  ViewControllerName.swift
//  Class03
//
//  Created by Blaser, Elliott on 9/16/19.
//  Copyright © 2019 Blaser, Elliott. All rights reserved.
//

import UIKit

class ViewControllerName: UIViewController {

    
    @IBOutlet weak var LabelName: UILabel!
    var name:String?
    
    @IBOutlet weak var LabelEmail: UILabel!
    var email:String?
    
    @IBOutlet weak var TextFieldPassword: UITextField!
    var password:String?
    
    @IBOutlet weak var LabelDepartment: UILabel!
    var department:String?
    
    @IBOutlet weak var ShowHidePass: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if(name != "")
        {
            self.LabelName.text = name
        }
        if(email != "")
        {
            self.LabelEmail.text = email
        }
        if(password != "")
        {
            self.TextFieldPassword.text = password
        }
        self.LabelDepartment.text = department
        
    }
    
    @IBAction func ShowHide(_ sender: Any) {
        if(self.TextFieldPassword.isSecureTextEntry == true)
        {
            ShowHidePass.setTitle("Hide", for: .normal)
            self.TextFieldPassword.isSecureTextEntry = false
        }
        else
        {
            ShowHidePass.setTitle("Show", for: .normal)
            self.TextFieldPassword.isSecureTextEntry = true
        }
    }
    
    @IBAction func CloseName(_ sender: Any) {
        self.dismiss(animated: true)
    }
    
    @IBAction func UnwindAction(segue:UIStoryboardSegue)
    {
        if self.name != nil
        {
            //print ("name update")
            LabelName.text = self.name
        }
        
        if self.email != nil
        {
            //print("email update")
            LabelEmail.text = self.email
        }
        
        if self.password != nil
        {
            //print("passupdate")
            ShowHidePass.setTitle("Show", for: .normal)
            self.TextFieldPassword.isSecureTextEntry = true
            TextFieldPassword.text = self.password
        }
        self.LabelDepartment.text = self.department
    }

    
   
    
}
