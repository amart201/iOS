//
//  ViewControllerEditPass.swift
//  Class03
//
//  Created by Blaser, Elliott on 9/16/19.
//  Copyright © 2019 Blaser, Elliott. All rights reserved.
//

import UIKit

class ViewControllerEditPass: UIViewController {

    @IBOutlet weak var TextFieldPass: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func CloseEditName(_ sender: Any) {
        self.dismiss(animated: true)
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vc = segue.destination as! ViewControllerName
        vc.password = self.TextFieldPass.text
    }
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        if (self.TextFieldPass.text == "")
        {
            let alert = UIAlertController(title: "Error!", message: "You need to enter a password!", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Splendid!", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            return false
        }
        else
        {
            return true
        }
    }

}
